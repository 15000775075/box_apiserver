<?php

namespace epay\lib;
/* *
 * 配置文件
 */

//支付接口地址
$epay_config['apiurl'] = 'https://pay.50app.cn/';

//商户ID
$epay_config['pid'] = '1000';

//商户密钥
$epay_config['key'] = 'C43Y0PCW';
